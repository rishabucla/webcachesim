pull from master
create booster_data folder with booster_0.data file

Tanmay

Plain LFO

```
/cdn1_500m_sigmetrics18.tr LRU 4294967296 0 0 > vanilla.log
```
Arnav Garg

Plain LFO + RL Cache features
```
/cdn1_500m_sigmetrics18.tr LRU 4294967296 0 1 > rl_cache.log
```
Rishab Doshi

Plain LFO + Exp Time gap
```
/cdn1_500m_sigmetrics18.tr LRU 4294967296 1 0 > exp_time_gap.log
```
