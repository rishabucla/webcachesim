import matplotlib.pyplot as plt

# def get_hits(filename):
#     hits = []
#     with open(filename) as f:
#         for line in f:
#             if line.startswith("[+] Number of hits"):
#                 hits.append(int(line.split()[-1]))
#     return hits
#
#
# vanilla_hits = get_hits('vanilla.logs')
# rlcache_hits = get_hits('rlcache.logs')
# exp_hits = get_hits('exp.logs')
# rlexp_hits = get_hits('rlexp.logs')
#
# # x = range(len(vanilla_hits))
# #
# # plt.plot(x, vanilla_hits)
# # plt.plot(x, rlcache_hits)
# # plt.plot(x, exp_hits)
# # plt.plot(x, rlexp_hits)
# #
# # plt.legend(['vanilla', 'rlcache', 'exp', 'rlexp'], loc='lower right')
# #
# # plt.show()
#
#
# def get_average(hits):
#     sum = 0.0
#     for i in hits:
#         sum += i
#     return sum/(len(hits)*1000000)
#
#
# vanilla_ratio = get_average(vanilla_hits)
# rlcache_ratio = get_average(rlcache_hits)
# exp_ratio = get_average(exp_hits)
# rlexp_ratio = get_average(rlexp_hits)
lru_ratio = 0.207
fifo_ratio = 0.186
#gds_ratio = 0.658517
#gdsf_ratio = 0.687832
lfdua_ratio = 0.248
lruk_ratio = 0.195
adaptsize_ratio = 0.191
exp_ratio = 0.221

objects = ('LRU', 'FIFO', 'LFUDA', 'LRU-K', 'AdaptSize', 'LFO-ExpoGap')
y_pos = range(len(objects))
performance = [lru_ratio, fifo_ratio, lfdua_ratio, lruk_ratio, adaptsize_ratio, exp_ratio]

plt.barh(y_pos, performance, align='center', alpha=0.5)
plt.yticks(y_pos, objects)
plt.xlabel('Byte Hit Ratio')

plt.show()

